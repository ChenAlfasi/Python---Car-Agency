import csv
from VIPCustomers import *
from CollectorsVehicle import *
from Exceptions1 import *

class Store:
    def __init__(self,Vehicle_file2,Customer_file2):
        self.Collectorvehicles=[]
        self.vehicles=[]
        self.customers=[]
        self.VIPCustomers=[]

        with open(Vehicle_file2) as csv1:
            read1=csv.reader(csv1)
            next(read1)
            for row in read1 :
                if len(list(row))==6:
                    self.vehicles.append(Vehicle(row))
                else:
                    self.Collectorvehicles.append(CollectorsVehicle(row))
        with open(Customer_file2) as csv2:
            read2 = csv.reader(csv2)
            next(read2)
            for row1 in read2:
                if len(list(row1))==5:
                    self.customers.append(Customer(row1))
                else:
                    self.VIPCustomers.append(VIPCustomers(row1))


    def print_vehicles(self):
        for vehicle in self.vehicles:
            print(vehicle)

    def get_vehicle(self,number):
        ExceptionProcess.ChecklntNumbers(ExceptionProcess(),number,0,None,"Vehicle")
        for vehicle in self.vehicles:
            if int(number)==int(vehicle.licence_plate):
                return vehicle

    def add_vehicle(self,vehicle):
        for i in self.vehicles:
            if vehicle.licence_plate==i.licence_plate:
               return False
        self.vehicles.append(i)
        return True

    def remove_vehicle(self,number):
        ExceptionProcess.ChecklntNumbers(ExceptionProcess(),number, 0, None, "vehicle")
        for vehicle in self.vehicles:
            if vehicle.licence_plate == str(number):
                self.vehicles.remove(vehicle)
                return True
        return False

    def get_all_by_manufactrurer(self,manufacturer):
        ExceptionProcess.CheckStr(ExceptionProcess(), manufacturer,"vehicle")
        vlist_same_manufacturer=[]
        for vehicle in self.vehicles:
            if vehicle.manufacturer==manufacturer.capitalize():
                vlist_same_manufacturer.append(vehicle)
        print(vlist_same_manufacturer)

    def get_all_by_price_under(self,max_price):
        ExceptionProcess.ChecklntNumbers(ExceptionProcess(),max_price, 0, None, "vehicle")
        v_under_this_price=[]
        for vehicle in self.vehicles:
            if float(vehicle.price)<=float(max_price):
                v_under_this_price.append(vehicle)
        return v_under_this_price

    def print_vehicle_list(self,list_of_vehicle):
        ExceptionProcess.CheckList(ExceptionProcess(),list_of_vehicle,"vehicle")
        for vehicle in list_of_vehicle:
            vehicle.print_me()

    def get_most_expensive_vehicle(self):
        all_the_vehicles_price=[]
        for vehicle in self.vehicles:
            all_the_vehicles_price.append(int(vehicle.price))
        max_price=max(all_the_vehicles_price)
        for vehicle1 in self.vehicles:
            if int(vehicle1.price)==max_price:
               print(vehicle1)


    def print_customers(self):
        for customer in self.customers:
            print(customer)

    def get_customer(self, id):
        ExceptionProcess.ChecklntNumbers(ExceptionProcess(),id, 0, None, "customer")
        for customer in self.customers:
            if customer.customer_id==id:
                return customer

    def add_customer(self,customer):
        for i in self.customers:
            if i.customer_id==customer.customer_id:
                return False
        self.customers.append(customer)
        return True

    def remove_customer(self,customer_id):
        ExceptionProcess.ChecklntNumbers(ExceptionProcess(),customer_id, 0, None, "customer")
        for customer in self.customers:
            if customer.customer_id==str(customer_id):
                self.customers.remove(customer)
                return True
        return False


#project2 functions:#

    def Get_All_Collector(self):
        return self.Collectorvehicles

    def Get_all_by_km_under(self,num_of_km):
        ExceptionProcess.ChecklntNumbers(ExceptionProcess(),num_of_km,0,None,"vehicle")
        all_the_cars_under_this_km=[]
        for car in self.Collectorvehicles:
            if float(car.Km)<float(num_of_km):
                all_the_cars_under_this_km.append(car)
        print(all_the_cars_under_this_km)

    def Get_All_Vip(self):
        return self.VIPCustomers

    def Get_all_entitled(self):
        c1=[]
        for customer in self.VIPCustomers:
            if customer.joiningpresent==True:
                c1.append(customer)
        return c1

    def print_all_customers(self):
        for i in self.customers:
            print(i)
        for j in self.VIPCustomers:
            print(j)

    def print_all_VIP(self):
        return self.VIPCustomers





