from Exceptions1 import *

class Vehicle:
    def __init__(self,vehicle_list):
        self.licence_plate=eval(vehicle_list[0])
        self.vehicle_type=vehicle_list[1]
        self.manufacturer=vehicle_list[2]
        self.model=vehicle_list[3]
        self.year=eval(vehicle_list[4])
        self.price=eval(vehicle_list[5])
        ExceptionProcess.ChecklntNumbers(ExceptionProcess(),self.year,1000, 9999,"Vehicle")
        ExceptionProcess.ChecklntNumbers(ExceptionProcess(),self.price,1000,3000000,"Vehicle")
        ExceptionProcess.ChecklntNumbers(ExceptionProcess(),self.licence_plate,10000000,99999999,"Vehicle")



    def print_me(self):
        return print("---"+str(self.licence_plate)+"---\n","type:"+self.vehicle_type+"\n",\
                     "manufacturer:"+self.manufacturer+"\n","model:"+self.model+"\n",\
                     "year:"+str(self.year)+"\n","price:"+str(self.price),"$")
    def is_collector(self):
        return False

    def __str__(self):
        returned= str(self.licence_plate)+","+self.vehicle_type+","+self.manufacturer+","+\
                     self.model+","+str(self.year)+","+str(self.price)
        return returned

    def __repr__(self):
        return str(self)



