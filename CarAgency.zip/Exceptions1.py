class ExceptionVehicle(Exception):
    def __init__(self,Message,Level,Source):
        self.Message=Message
        self.Level=int(Level) #Choose a number between 1(lower) to 5(highest).
        self.Source=Source

    def __str__(self):
        back=self.Message+"."+" Level of severity is: "+str(self.Level)+". Source object: "+self.Source+"."
        return back

    def __repr__(self):
        return str(self)

class ExceptionProcess():
    def __init__(self):
        pass

    def ChecklntNumbers(self, var, minimum, maximum, source):
        if isinstance(var, int) == False:
            raise ExceptionVehicle("The var is not int", 5, source)
        else:
            if (maximum is not None) and (minimum is not None):
                if minimum<var<maximum:
                    pass
                else: raise ExceptionVehicle("The var is not in the range",3,source)
            else:
                if maximum is None:
                    if var<minimum:
                        raise ExceptionVehicle("The var is not in the range", 3, source)
                if minimum is None:
                    if var>maximum:
                        raise ExceptionVehicle("The var is not in the range", 3, source)



    def CheckStr(self,var,source):
        if isinstance(var,str)==False:
            raise ExceptionVehicle("Var is not a String",5,source)
        if isinstance(var,str) and len(var)==0:
            raise ExceptionVehicle("Var is an empty String",3,source)

    def CheckList(self,var,source):
        if isinstance(var,list)==False:
            raise ExceptionVehicle("Var is not a List", 5, source)
        if isinstance(var, list) and len(var) == 0:
            raise ExceptionVehicle("Var is an empty List", 3, source)

    def CheckDictionary(self,var,source):
        if isinstance(var,dict)==False:
            raise ExceptionVehicle("Var is not a Dict", 5, source)
        if isinstance(var, dict) and len(var) == 0:
            raise ExceptionVehicle("Var is an empty Dict", 3, source)

    def CheckTuple(self,var,source):
        if isinstance(var,tuple)==False:
            raise ExceptionVehicle("Var is not a Tuple", 5, source)
        if isinstance(var, tuple) and len(var) == 0:
            raise ExceptionVehicle("Var is an empty Tuple", 3, source)







