from Vehicle import *
from Exceptions1 import *

class CollectorsVehicle(Vehicle):
    def __init__(self,vehicle_list):
        super().__init__(vehicle_list[0:6])
        self.Km=eval(vehicle_list[6])
        self.Old_Oweners=vehicle_list[7]
        self.Test=tuple(eval(vehicle_list[8]))
        ExceptionProcess.ChecklntNumbers(ExceptionProcess(),self.Km,0,None,"CollectorsVehicle")

    def print_me(self):
        return print("---" + self.licence_plate + "---\n", "type:" + self.vehicle_type + "\n",
              "manufacturer:" + self.manufacturer + "\n", "model:" + self.model + "\n",
              "year:" + self.year + "\n", "price:" + self.price, "$" + "\n",
              "km:" + str(self.Km )+ "\n","old owners:" +self.Old_Oweners +"\n",
              "The last test:" + str(self.Test))

    def __str__(self):
        back=","+str(self.Km)+","+self.Old_Oweners+","+str((self.Test))
        return super().__str__()+back

    def __repr__(self):
        return str(self)

    def is_collector(self):
        return True




