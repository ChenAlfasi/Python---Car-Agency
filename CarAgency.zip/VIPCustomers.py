from Customer import *
class VIPCustomers(Customer):
    def __init__(self,customer_list):
        super().__init__(customer_list[0:5])
        self.startdate=tuple(eval(customer_list[5]))
        self.birthdate=tuple(eval(customer_list[6]))
        self.joiningpresent=customer_list[7]
        self.check_present(customer_list[7])

    def check_present(self,present):
        if present=="False":
            self.joiningpresent=False
        else:
            self.joiningpresent=True


    def __str__(self):
        back=str(self.customer_id)+","+self.customer_name+","+self.customer_adress+","+\
             str(self.customer_phone_number)+","+self.customer_gender+","+str(self.startdate)+","+\
             str(self.birthdate)+","+str(self.joiningpresent)
        return back

    def __repr__(self):
        return str(self)

    def Get_present(self):
        if self.joiningpresent==True:
            print("Congratulations here is your present")
            self.joiningpresent=False
        else: print("you already got your present!")



