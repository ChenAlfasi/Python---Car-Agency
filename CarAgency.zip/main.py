from Store_forEx3 import *
from tkinter import *
from tkinter.ttk import *
from tkinter import messagebox

try:
    s = Store("vehicles.csv", 'customers.csv')
    print("All the Vehicles in the store :", s.vehicles)
    print("All the Customers of the store :", s.customers)
    new_vehicle = Vehicle(["87965601", "Car", "Kia", "Picanto", "2019", "18002"])
    s.add_vehicle(new_vehicle)
    s.remove_vehicle(87965601)
    print("List of kia's cars :", s.get_all_by_manufactrurer("kia"))
    print("List of BMW's cars :", s.get_all_by_manufactrurer("BMW"))
    print("All the vehicle under 15,000$ :", s.get_all_by_price_under(15000))
    print("The most expensive vehicle in the store is:", s.get_most_expensive_vehicle())
    new_customer = Customer(["13571", "omer mizrahi", "zealon 2", "0507634441", "M"])
    s.add_customer(new_customer)
    s.remove_customer(13571)
    print("\n")
    ###project2##
    print(s.Get_All_Collector())
    print(s.Get_all_by_km_under(15000))  # none
    print(s.Get_All_Vip())
    print(s.Get_all_entitled())

except ExceptionVehicle as ex:
    print(ex)
except:
    print("Exception!!")
else:
    print("Everything worked Good!")
print("Continue")

window = Tk()
window.configure(bg="yellow")
window.geometry("800x400")
window.title("Store Of Vehicles")
lbl1 = Label(window, text="Buy A Car", font=("d bold", 30))
lbl1.grid(column=0, row=0)

def print_customers():
    sen = "You Printed All The Customers"
    lbl1.configure(text=sen)
    s.print_all_customers()
    messagebox.showinfo("Customers","You Printed All The Customers")

bun_add1 = Button(window, text="Print All customers", command=print_customers)
bun_add1.grid(column=0, row=1)

def print_vehicles():
    sen = "You Printed All The Vehicles"
    lbl1.configure(text=sen)
    s.print_vehicles()
    messagebox.showinfo("Vehicles", "You Printed All The Vehicles")

bun_add2 = Button(window, text="Print All Vehicles", command=print_vehicles)
bun_add2.grid(column=0, row=2)
txt1 = Entry(window, width=30)
txt1.grid(column=0, row=3)
txt1.focus()

def Vehicle_Of_Man():
    sen = "You Printed All The Vehicles Of: " + txt1.get() + " Manufacturer"
    lbl1.configure(text=sen)
    man = txt1.get()
    s.get_all_by_manufactrurer(man)
    messagebox.showinfo("Vehicles", "You Printed All The " +txt1.get()+" Vehicles")

bun_add3 = Button(window, text="Print All the Vehicle From Specific Manufacturer", width=50, command=Vehicle_Of_Man)
bun_add3.grid(column=1, row=3)
txt2 = Entry(window, width=30)
txt2.grid(column=0, row=4)

def Under_money():
    lbl1.configure(text="You Printed All the Vehicle Under This amount:" + txt2.get())
    mon = int(txt2.get())
    print(s.get_all_by_price_under(mon))
    messagebox.showinfo("Vehicles", "You Printed All The Vehicles Under "+txt2.get()+"$")

bun_add4 = Button(window, text="Print All the Vehicle Under This amount of Money", width=60, comman=Under_money)
bun_add4.grid(column=1, row=4)

def most_expensive_vehicle():
    s.get_most_expensive_vehicle()
    lbl1.configure(text="Printed All Expensive Vehicles")
    messagebox.showinfo("Vehicles", "You Printed The Most Expensive Vehicles")

bun_add5 = Button(window, text="Display And Print All Expensive Vehicles", command=most_expensive_vehicle)
bun_add5.grid(column=0, row=5)

def Get_All_Collector():
    print(s.Get_All_Collector())
    lbl1.configure(text="Printed All Collection Vehicles")
    messagebox.showinfo("Vehicles", "You Printed All Collection Vehicles")

bun_add6 = Button(window, text="Print All Collection Vehicles", command=Get_All_Collector)
bun_add6.grid(column=0, row=6)
txt3 = Entry(window, width=30)
txt3.grid(column=0, row=7)


def Vehicles_Under_Km():
    sen = "You Printed All The Vehicles Under " + txt3.get() + " KM"
    lbl1.configure(text=sen)
    man = txt3.get()
    man1 = int(man)
    s.Get_all_by_km_under(man1)
    messagebox.showinfo("Vehicles", "You Printed All The Vehicles Under " + txt3.get() + " KM")

bun_add6 = Button(window, text="Print All Collection Vehicles Under KM", command=Vehicles_Under_Km)
bun_add6.grid(column=1, row=7)

def Get_All_Vip():
    lbl1.configure(text="You Printed All Vip Customers")
    print(s.print_all_VIP())
    messagebox.showinfo("VIP-Customers","You Printed All Vip Customers")

bun_add6 = Button(window, text="Print All Vip Customers", command=Get_All_Vip)
bun_add6.grid(column=0, row=8)
window.mainloop()

