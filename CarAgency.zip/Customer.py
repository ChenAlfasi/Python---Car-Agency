from Exceptions1 import *
class Customer:
    def __init__(self,customer_list):
        self.customer_id=customer_list[0]
        self.customer_name=customer_list[1]
        self.customer_adress=customer_list[2]
        self.customer_phone_number=customer_list[3]
        self.customer_gender=customer_list[4]
        self.gender()
        ExceptionProcess.CheckStr(ExceptionProcess(),self.customer_gender,"customer")

    def gender(self):
        if self.customer_gender.strip() not in ["F","M"]:
            self.customer_gender="F"

    def print_me(self):
        return print("---"+str(self.customer_id)+"---"+"\n","customer name :"+self.customer_name+"\n",\
        "customer adress:"+self.customer_adress+"\n","customer phone:"+str(self.customer_phone_number)+"\n",\
        "customer gender:"+self.customer_gender)

    def __str__(self):
        back1=str(self.customer_id)+","+self.customer_name+","+self.customer_adress+","+\
                     str(self.customer_phone_number)+","+self.customer_gender
        return back1

    def __repr__(self):
        return str(self)


